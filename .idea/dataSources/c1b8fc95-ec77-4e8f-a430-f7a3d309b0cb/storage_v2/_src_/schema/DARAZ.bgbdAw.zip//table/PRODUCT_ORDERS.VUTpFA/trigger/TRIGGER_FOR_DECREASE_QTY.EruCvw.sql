create trigger TRIGGER_FOR_DECREASE_QTY
    after insert
    on PRODUCT_ORDERS
    for each row
DECLARE
		Productid Number;
        OrderId number;
        qty1 number;
        oldqty number;
        newqty number;
        catid number;


BEGIN
        Productid := :NEW.PRODUCT_ID;
		OrderId := :NEW.ORDER_ID;
        select QUANTITY into qty1 from ORDERS where ORDERS.ORDER_ID = OrderId;
        select CAT_ID into catid from PRODUCTS where PRODUCT_ID = Productid;
        DECREASE_ITEMQTY(qty1,Productid);
        DECREASE_CATQTY(qty1,catid);

--         newqty := oldqty - qty1;
--         if newqty < 0 then
--             newqty :=0;
--         end if;
--         update PRODUCTS
--           set QUANTITY = newqty
--           where PRODUCTS.PRODUCT_ID = Productid;


exception
    WHEN too_many_rows THEN
        dbms_output.put_line('Errors fetching are more than one');

    when others then
        dbms_output.put_line('Unknown error occured!');

END;
/

