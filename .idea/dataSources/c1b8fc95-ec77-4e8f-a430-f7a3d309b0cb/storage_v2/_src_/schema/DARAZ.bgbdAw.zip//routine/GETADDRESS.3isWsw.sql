create FUNCTION getAddress(userid number)
return Varchar2
IS
    billingadd varchar2(1000);


BEGIN
    select BILLING_ADDRESS into billingadd from PEOPLE where CUSTOMER_ID = userid;
    if billingadd is null then
        select ADRESS into billingadd from PEOPLE where  CUSTOMER_ID = userid;
    end if;
     return billingadd;


exception
   WHEN too_many_rows THEN
        dbms_output.put_line('Errors fetching are more than one');
        return 'Address not Found!';

    when others then
        dbms_output.put_line('Unknown error occured!');
                return 'Address not Found!';



END getAddress;
/

