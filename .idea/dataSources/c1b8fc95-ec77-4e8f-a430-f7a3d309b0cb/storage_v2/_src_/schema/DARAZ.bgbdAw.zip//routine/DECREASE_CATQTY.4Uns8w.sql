create PROCEDURE decrease_catQty
  ( qty          in number
   ,catid     in number

   )
IS
    oldqty number;
    newqty number;
BEGIN

  select QUANTITY into oldqty from CATAGORIES where CAT_ID = catid;

  DBMS_OUTPUT.PUT_LINE(oldqty);
  newqty := oldqty - qty;
  if newqty < 0 then
      newqty :=0;
  end if;
  update CATAGORIES
      set QUANTITY = newqty
    where CAT_ID = catid;

 exception
    WHEN too_many_rows THEN
        dbms_output.put_line('Errors fetching are more than one');

    when others then
        dbms_output.put_line('Unknown error occured!');


END decrease_catQty;
/

