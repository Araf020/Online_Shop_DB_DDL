create trigger TRIGGER_FOR_SHIPPING
    after insert
    on PAYMENTS
    for each row
DECLARE
        OrderId number;
        pay_method varchar2(50);
        pay_status varchar2(50);
        orderdate date;
        userid number;
        shipdate date;


BEGIN

		OrderId := :NEW.ORDER_ID;
		pay_method := :NEW.METHOD;
		pay_status := :NEW.PAYMENT_STATUS;
        select ORDER_DATE,CUSTOMER_ID into orderdate,userid from ORDERS where ORDERS.ORDER_ID = OrderId;
		shipdate := orderdate + 5;
		if LOWER(pay_status) = 'true' then
            INSERT into SHIPMENTS(shipment_id, shipment_date, order_id, status, deliveryat) VALUES (SHIPMENTID.nextval,shipdate,OrderId,'false',GETADDRESS(userid));
        else

            if lower(pay_method) = 'cash_on_delivery' then
            INSERT into SHIPMENTS(shipment_id, shipment_date, order_id, status, deliveryat) VALUES (SHIPMENTID.nextval,shipdate,OrderId,'false',GETADDRESS(userid));

            end if;

        end if;




exception
    WHEN too_many_rows THEN
        dbms_output.put_line('Errors fetching are more than one');

    when others then
        dbms_output.put_line('Unknown error occured!');

END;
/

