create PROCEDURE decrease_itemQty
  ( qty          in number
   ,itemid     in number

   )
IS
    oldqty number;
    newqty number;
BEGIN

  select QUANTITY into oldqty from PRODUCTS where PRODUCT_ID = itemid;

  DBMS_OUTPUT.PUT_LINE(oldqty);
  newqty := oldqty - qty;
  if newqty < 0 then
      newqty :=0;
  end if;
  update PRODUCTS
      set QUANTITY = newqty
    where PRODUCT_ID = itemid;

 exception
    WHEN too_many_rows THEN
        dbms_output.put_line('Errors fetching are more than one');

    when others then
        dbms_output.put_line('Unknown error occured!');


END decrease_itemQty;
/

